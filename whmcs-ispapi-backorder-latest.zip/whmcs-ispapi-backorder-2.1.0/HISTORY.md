# [2.1.0](https://github.com/hexonet/whmcs-ispapi-backorder/compare/v2.0.4...v2.1.0) (2018-10-19)


### Features

* **releaseInfo:** add json file covering repository info ([37d83ab](https://github.com/hexonet/whmcs-ispapi-backorder/commit/37d83ab))

## [2.0.4](https://github.com/hexonet/whmcs-ispapi-backorder/compare/v2.0.3...v2.0.4) (2018-10-19)


### Bug Fixes

* **IDNAConvert:** review adding vendor folder to archives ([7a2a432](https://github.com/hexonet/whmcs-ispapi-backorder/commit/7a2a432))

## [2.0.3](https://github.com/hexonet/whmcs-ispapi-backorder/compare/v2.0.2...v2.0.3) (2018-10-18)


### Bug Fixes

* **IDNAConvert:** just add the vendor folder partially ([bd01cbb](https://github.com/hexonet/whmcs-ispapi-backorder/commit/bd01cbb))

## [2.0.2](https://github.com/hexonet/whmcs-ispapi-backorder/compare/v2.0.1...v2.0.2) (2018-10-18)


### Bug Fixes

* **IDNAConvert:** include vendor folder in archives ([1fcf207](https://github.com/hexonet/whmcs-ispapi-backorder/commit/1fcf207))

## [2.0.1](https://github.com/hexonet/whmcs-ispapi-backorder/compare/v2.0.0...v2.0.1) (2018-10-18)


### Bug Fixes

* **IDNAConvert:** switch to new library ([889746c](https://github.com/hexonet/whmcs-ispapi-backorder/commit/889746c))

# [2.0.0](https://github.com/hexonet/whmcs-ispapi-backorder/compare/v1.1.3...v2.0.0) (2018-10-18)


### Code Refactoring

* **pkg:** Initial GitHub release ([#1](https://github.com/hexonet/whmcs-ispapi-backorder/issues/1)) ([5e5a21e](https://github.com/hexonet/whmcs-ispapi-backorder/commit/5e5a21e))


### BREAKING CHANGES

* **pkg:** Need to trigger a new major release as we switched to github and added CI/CD
